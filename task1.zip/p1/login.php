<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: welcome.php");
  exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: welcome.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = "No account found with that username.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secret Diary</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
    body{
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: url(bg.jpg) no-repeat;
    background-size: cover;
    }
    .wrapper {
    width: 400px;
    border: 1px solid #CCC;
    background: url(http://68.media.tumblr.com/2b27908fac782ca54cc2b3aff6862423/tumblr_mra3owkIhC1ro855no1_500.gif) center center no-repeat;
    background-size: cover;
    margin:  100px auto;
    border-radius: 12px;
    opacity: 0.9;
    z-index: -1;
  }

  h2 {
    color:white;
    text-align: center;
    font-weight: normal;
    font-size: 32px;
    margin-top: 25px;
    margin-bottom: 0px;
  }
  .wrapper form {
    width: 100%;
    height: 100%;
    padding: 9px 32px;
  }
  .wrapper form input {
    width: 100%;
    height: 40px;
    margin-top: 20px;
    background: black;
    border: 3px solid white;
    padding: 0 15px;
    color: #FFF;
    border-radius: 8px;
    font-size: 14px;

  }
  .wrapper form input:focus {
    border: 1px solid rgba(255,255,255,.8);
    outline: none;
  }
  .wrapper .form-control{ /* Edge */
    color:white;
   font-weight: bold;
}
.p1{
    color:white;
    text-align: center;
    font-weight: normal;
    font-size: 15px;
    margin-top: 0px;
    margin-bottom: 15px;
  }
  .p2{
    color:white;
    text-align: center;
    font-weight: normal;
    font-size: 13px;
    margin-top: 20px;
    margin-bottom: -11px;
  }
  p{
    color:white;
    text-align: center;
    font-weight: normal;
    font-size: 15px;
    margin-top: 0px;
    margin-bottom: 15px;
  }
  
    </style>
</head>
<body>
    <div class="wrapper">
    <h2>SECRET DIARY</h2>
        
          <p class="p1">Store Your Thoughts Permanently and Securely</p>
          <p class="p2">Interested? SignUp Now</p>
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                
                <input type="text" placeholder="Your Email" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                
                <input type="password" placeholder="Password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
        </form>
    </div>    
</body>
</html>